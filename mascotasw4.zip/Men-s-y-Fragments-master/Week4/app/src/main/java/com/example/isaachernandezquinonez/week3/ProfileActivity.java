package com.example.isaachernandezquinonez.week3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        TextView toolbar_title_standar = (TextView) findViewById(R.id.toolbar_title_standar);
        toolbar_title_standar.setText(R.string.txtAcerca);
        Toolbar miActionBar_standar = (Toolbar) findViewById(R.id.miActionBar_standar);
        setSupportActionBar(miActionBar_standar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
