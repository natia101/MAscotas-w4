package com.example.isaachernandezquinonez.week3;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.PagerAdapter;

import java.util.ArrayList;

/**
 * Created by isaachernandezquinonez on 26/06/16.
 */
public class AdapterFragment extends FragmentPagerAdapter{
    private ArrayList<Fragment> fragments;

    public AdapterFragment(FragmentManager fm, ArrayList<Fragment> fragments){
        super(fm);
        this.fragments = fragments;

    }
    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }
}
